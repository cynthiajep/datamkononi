// This script is empty as we don't need it for this extension.
