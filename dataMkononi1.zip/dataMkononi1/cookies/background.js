chrome.runtime.onInstalled.addListener(() => {
    chrome.action.openPopup();
  });
  